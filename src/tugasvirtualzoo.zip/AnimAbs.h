#ifndef ANIMABS_H
#define ANIMABS_H

//Class Animal dan turunannya (famili animal dan tipe animal)
class Animal {
  public :
  	virtual void Eat() const = 0;
  private :
  	int animal_weight;
	int animal_type;		
};

class LandAnimal : public Animal {
	public :
		LandAnimal();
		virtual void Eat();
};

class AirAnimal : public Animal {
	public :
		AirAnimal();
		virtual void Eat();
};

class WaterAnimal : public Animal {
	public :
		WaterAnimal();
		virtual void Eat();
};

class Felidae : public LandAnimal {
	public :
		Felidae();
		virtual void Eat();
};

class Giraffidae : public LandAnimal {
	public :
		Giraffidae();
		virtual void Eat();
};

class Ursidae : public LandAnimal {
	public :
		Ursidae();
		virtual void Eat();
};

class Equidae : public LandAnimal {
	public :
		Equidae();
		virtual void Eat();
};

class Scorpaenidae : public WaterAnimal {
	public :
		Scorpaenidae();
		virtual void Eat();
};

class Delphidae : public WaterAnimal {
	public :
		Delphidae();
		virtual void Eat();
};

class Selachii : public WaterAnimal {
	public :
		Selachii();
		virtual void Eat();
};

class Octopodiae : public WaterAnimal {
	public :
		Octopodiae();
		virtual void Eat();
};

class Columbidae : public AirAnimal {
	public :
		Columbidae();
		virtual void Eat();
};

class Accipitridae : public AirAnimal {
	public :
		Accipitridae();
		virtual void Eat();
};

class Molossidae : public AirAnimal {
	public :
		Molossidae();
		virtual void Eat();
};

class Paradisaeidae : public AirAnimal {
	public :
		Paradisaeidae();
		virtual void Eat();
};

class TipeAnimal {
	public :
	private :
};

class Herbivora : public TipeAnimal {
	public :
	private :
};

class Karnivora : public TipeAnimal {
	public :
	private :
};

class Omnivora : public TipeAnimal {
	public :
	private :
};

#endif
